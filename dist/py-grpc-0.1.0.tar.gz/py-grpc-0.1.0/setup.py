# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['py_grpc', 'py_grpc.commands']

package_data = \
{'': ['*']}

install_requires = \
['grpcio-health-checking>=1.51.1,<2.0.0',
 'grpcio-tools>=1.51.1,<2.0.0',
 'grpcio>=1.51.1,<2.0.0',
 'mypy-protobuf>=3.4.0,<4.0.0',
 'pydantic>=1.10.2,<2.0.0']

entry_points = \
{'console_scripts': ['build-protobufs = py_grpc.commands.build_protobufs:build',
                     'grpc-server = py_grpc.server:serve']}

setup_kwargs = {
    'name': 'py-grpc',
    'version': '0.1.0',
    'description': 'Framework to create a GRPC server in Python',
    'long_description': None,
    'author': 'Aditya Mattos',
    'author_email': 'adityamattos@hey.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
