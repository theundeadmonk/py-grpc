from pydantic import BaseSettings


class GRPCSettings(BaseSettings):
    """
    GRPC Configuration
    Attributes:
        host: Host to bind to
        port: Port to bind to
        threads: No of threads to start the server with
    """

    host: str = "0.0.0.0"
    port: int = 50051
    threads: int = 10
