import grpc
import logging
from concurrent import futures

from grpc.health.v1 import health, health_pb2_grpc


from py_grpc.settings import GRPCSettings

logger = logging.getLogger(__name__)

settings = GRPCSettings()


def _configure_health_check(server: grpc.Server) -> None:
    # Health Check
    health_servicer = health.HealthServicer(
        experimental_non_blocking=True,
        experimental_thread_pool=futures.ThreadPoolExecutor(
            max_workers=settings.threads
        ),
    )
    health_pb2_grpc.add_HealthServicer_to_server(health_servicer, server)


def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=settings.threads))
    _configure_health_check(server)
    port = settings.port
    server.add_insecure_port(f"[::]:{port}")
    server.start()
    logger.info(f"GRPC Server listining on port: {port}")
    server.wait_for_termination()
